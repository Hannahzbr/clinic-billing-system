import tkinter as tk
from tkinter import messagebox as msg


class LabelStd(tk.Label):
    def __init__(self, master, r, c, text, var=None, **kwargs):
        super().__init__(master, text=text, textvariable=var, **kwargs)
        self["font"] = "Arial 12"
        self.grid(row=r, column=c, sticky="W", padx=5, pady=3)


class ButtonStd(tk.Button):
    def __init__(self, master, r, c, text, func, **kwargs):
        super().__init__(master, text=text, command=func, **kwargs)
        self["font"] = "Arial 12"
        self.grid(row=r, column=c, sticky="NEWS", padx=5, pady=3)


class CheckBoxStd(tk.Checkbutton):
    def __init__(self, master, r, c, text, var=None, **kwargs):
        super().__init__(master, text=text, variable=var, **kwargs)
        self["font"] = "Arial 12"
        self.config(onvalue=1, offvalue=0)
        self.grid(row=r, column=c, sticky="W", padx=5, pady=3)


class RadioBtnStd(tk.Radiobutton):
    def __init__(self, master, text, var=None, val=-1, **kwargs):
        super().__init__(master, text=text, variable=var, **kwargs)
        self.config(font="Arial 12")
        self.config(value=val)
        self.pack(side="left", padx=5, pady=3)


class TextStd(tk.Entry):
    def __init__(self, master, r, c, var, **kwargs):
        super().__init__(master, textvariable=var, **kwargs)
        self["font"] = "Arial 12"
        self.grid(row=r, column=c, sticky="NEWS", padx=5, pady=3)


class Application:
    def __init__(self):
        self.frm_main = tk.Tk()
        self.frm_main.title("Sale Records")
        self.frm_main.minsize(400, 600)
        self.frm_main.maxsize(400, 600)
        self.frm_main.iconbitmap("FavIcon.ico")

        self.quantity = tk.StringVar()
        self.price = tk.StringVar()
        self.sum = tk.StringVar()
        self.delivery = tk.IntVar()
        self.insurance = tk.IntVar()
        self.r = 0
        self.type = tk.IntVar()

        self.image = tk.PhotoImage(file="header.png")
        self.header = LabelStd(self.frm_main, 0, 0, "", image=self.image, width=390, height=130)
        self.header.grid(columnspan=2)

        LabelStd(self.frm_main, self.f_next_row(), 0, "Quantity")
        TextStd(self.frm_main, self.f_next_row(), 0, self.quantity)

        LabelStd(self.frm_main, self.f_next_row(), 0, "Price")
        TextStd(self.frm_main, self.f_next_row(), 0, self.price)

        CheckBoxStd(self.frm_main, self.f_next_row(), 0, "Delivery", self.delivery)
        CheckBoxStd(self.frm_main, self.f_next_row(), 0, "Insurance", self.insurance)

        self.frame_type = tk.Frame(self.frm_main)
        # self.rb1 = RadioBtnStd(self.frame_type, "A", self.type, 1)
        # self.rb2 = RadioBtnStd(self.frame_type, "B", self.type, 2)
        # self.rb3 = RadioBtnStd(self.frame_type, "C", self.type, 3)
        self.rb1 = RadioBtnStd(self.frame_type, "A", self.type, 100)
        self.rb2 = RadioBtnStd(self.frame_type, "B", self.type, 200)
        self.rb3 = RadioBtnStd(self.frame_type, "C", self.type, 500)

        self.frame_type.grid(row=self.f_next_row(), column=0, sticky="NEWS", padx=5, pady=3)

        ButtonStd(self.frm_main, self.f_next_row(), 0, "Calculate", self.f_calculate)
        LabelStd(self.frm_main, self.f_next_row(), 0, "Sum")
        self.lbl_res = LabelStd(self.frm_main, self.f_next_row(), 0, " ", self.sum)
        self.lbl_res.config(font="Arial 16 bold")

        self.type.set(100)
        self.frm_main.mainloop()

    def f_calculate(self):
        try:
            quantity = int(self.quantity.get())
            price = int(self.price.get())
            sum = quantity * price
            dl = self.delivery.get()
            percent = 0
            if dl:
                percent = 7
            ins = self.insurance.get()
            if ins:
                percent += 3
            sum *= (100 + percent) / 100
            sum += self.type.get()
            # sum += {1: 100, 2: 200, 3: 500, -1: 0}[tp]
            self.sum.set(f"{sum:0.2f} $")
        except:
            msg.showerror("Error", "Invalid Data!")

    def f_next_row(self):
        self.r += 1
        return self.r


a1 = Application()
