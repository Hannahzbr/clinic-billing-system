# Clinic Billing System 

A desktop application built with Python and Tkinter that simulates a clinic's billing desk. The user enters the quantity and price, chooses optional extras (delivery, insurance) and a plan type (A, B or C), and the app calculates the final amount the patient has to pay.

## Screenshot

![Clinic Billing System](screenshots/app.png)

## Fields

| Field | Description |
|-------|-------------|
| **Quantity** | Number of units / services (whole number) |
| **Price** | Price of one unit (whole number) |
| **Delivery** (checkbox) | Adds **7%** to the total |
| **Insurance** (checkbox) | Adds **3%** to the total |
| **Type A / B / C** (radio buttons) | Adds a fixed fee: **A = $100**, **B = $200**, **C = $500** |
| **Calculate** | Calculates and shows the result |
| **Sum** | The final amount to pay |

## How the total is calculated

```
base   = Quantity x Price
extras = 7% if Delivery is checked  +  3% if Insurance is checked
total  = base x (1 + extras) + type fee (A: 100, B: 200, C: 500)
```

If both Delivery and Insurance are checked, the extras are 10% in total.

### Examples

| Quantity | Price | Delivery | Insurance | Type | Result |
|---------:|------:|:--------:|:---------:|:----:|-------:|
| 2 | 50 | no | no | A | 100 + 100 = **$200.00** |
| 2 | 50 | yes | yes | A | 100 x 1.10 + 100 = **$210.00** |
| 3 | 200 | yes | no | B | 600 x 1.07 + 200 = **$842.00** |

## Error handling

If Quantity or Price is empty, or is not a whole number (for example `abc` or `2.5`), the app shows an **"Invalid Data!"** error message.

## Requirements

- **PyCharm** (Community or Professional)
- **Python 3.13** as the project interpreter
- Tkinter (included with the standard Python installation)
- Windows is recommended (the window icon uses a `.ico` file)

## How to Run

1. Download the project as a ZIP file and extract it.
2. Open **PyCharm** and choose **File → Open**, then select the extracted project folder.
3. Set the interpreter to Python 3.13:
   **File → Settings → Project → Python Interpreter → Add Interpreter → Select Python 3.13**
4. Open `main.py` and click **Run** (or press `Shift + F10`).

> **Important:** `header.png` and `FavIcon.ico` must stay in the same folder as `main.py`, otherwise the program will not start.

## Project Structure

```
clinic-billing-system/
├── main.py
├── header.png
├── FavIcon.ico
├── screenshots/
│   └── app.png
└── README.md
```

## Team

- Hannah Zebardast