# Clinic Billing System 🏥

A desktop application built with Python and Tkinter that simulates a clinic's billing desk. The user enters the quantity and price, selects the extra options (delivery, insurance) and a plan (A, B or C), and the app calculates the total amount to be paid.

## Screenshot

![Clinic Billing System](screenshots/app.png)

## Features

- Enter the **quantity** and **price** of the service/item
- Optional **Delivery** and **Insurance** checkboxes
- Choose a plan type: **A**, **B** or **C**
- One-click **Calculate** button that shows the final **Sum**
- Simple graphical interface with a header banner

## Requirements

- **PyCharm** (Community or Professional)
- **Python 3.13** as the project interpreter
- Tkinter (included with the standard Python installation)

## How to Run

1. Download the project as a ZIP file and extract it.
2. Open **PyCharm** and choose **File → Open**, then select the extracted project folder.
3. Set the interpreter to Python 3.13:
   **File → Settings → Project → Python Interpreter → Add Interpreter → Select Python 3.13**
4. Open `main.py` and click **Run** (or press `Shift + F10`).

## Usage

1. Type the quantity and the price.
2. Tick **Delivery** and/or **Insurance** if needed.
3. Select plan **A**, **B** or **C**.
4. Click **Calculate** to see the total in the **Sum** field.

## Project Structure

```
clinic-billing-system/
├── main.py
├── screenshots/
│   └── app.png
└── README.md
```

## Team

- Hannaneh Zebardast 

